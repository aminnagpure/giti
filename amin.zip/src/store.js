import Vue from 'vue'
import Vuex from 'vuex'
import axios from 'axios'

//import VuexPersistence from 'vuex-persist'

/*const vuexLocal = new VuexPersistence({
  storage: window.localStorage
})
*/


Vue.use(Vuex)

export default new Vuex.Store({
  state: {
    isLogged:false,
    datamongourl:"http://localhost:3000",
    exchangenames:[],
    chatmsg1:''
  },
  mutations: {
    loginMut:function(state){
      
      state.isLogged=true       
     // console.log('loginmut',state.isLogged)
    },
    logoutMut:function(state){
      state.isLogged=false      
    },
    setexchangenames:function(state,dd){    
      
      state.exchangenames=[]    
        
        dd.forEach((item)=> {   
        
        state.exchangenames.push(item.name)        
            
      });
      
    },
    chatposted:function(state){
      state.chatmsg1="done"
    }
  },
  getters:{
    arryofexchangenames(state){
      return state.exchangenames
    }
  },
  actions: {    
    actionsetExchangenames:function({commit}){
      axios.get(
        this.state.datamongourl +'/getexchangenames',{
          method:'GET',          
        }
      ).then((dd)=>{               
        commit('setexchangenames',dd.data)
      }).catch(()=>{
        
      //  console.log(err)
       // commit('getexchangenames',err)
      })
    },
    addExchange:function({commit},url){
      axios.get(
        this.state.datamongourl +'/addexchange?id='+url,{
          method:'GET',
          body:{
            id:url
          }
        }
      ).then(()=>{        
        commit('setexchangenames')
      }).catch(err=>{
        return err
      })
    },
    insertchat:function({commit}, dd){      
      axios.post(this.state.datamongourl + "/addchat",dd)
      .then(res=>res.data)
      .catch(err=>err)
      commit('chatposted')
    },
    loghimin:function({commit}){
     // console.log('loghimin action')
      commit('loginMut')
    },
    loghimout:function({commit}){
      commit('logoutMut')
    },    
  }
  //,
  //plugins: [vuexLocal.plugin]
})
