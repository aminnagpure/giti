<template>
  <div>
    <div :class="splclass">
      <div id="prevbal">{{prevbalance()}}</div>
      <div>{{differencebal()}}</div>
      <div>{{nowbalance()}}</div>
      <div>{{finalmsg}}</div>
    </div>
  </div>
</template>
<script>
import { allexchanges } from "../components/data";
export default {
  name: "completemarketwatch",
  data: function() {
    return { groups: [], splclass: "cssprops" };
  },
  created() {
    this.adddata();
  },
  methods: {
    adddata() {
      allexchanges.onSnapshot(kk => {
        kk.forEach(bb => {
          this.groups.push(bb.data());
        });
      });
    },
    differencebal() {
      if (this.groups.length > 0) {
        return (
          this.groups[0].totalethall -
          this.groups[this.groups.length - 1].totalethall
        );
      }
    },
    nowbalance() {
      if (this.groups.length > 0) {
        return "Now Balance " + this.groups[0].totalethall;
      }
    },
    prevbalance() {
      if (this.groups.length > 0) {
        return (
          "Previous balance " + this.groups[this.groups.length - 1].totalethall
        );
      }
    },
    allthegroup() {}
  },

  computed: {
    finalmsg() {
      if (this.differencebal() > 0) {
        this.splclass = "redclass";
        return "market will be red";
      } else {
        this.splclass = "greenclass";
        return "market will be Green";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.redclass {
  background-color: red;
}

.greenclass {
  background-color: green;
}
</style>