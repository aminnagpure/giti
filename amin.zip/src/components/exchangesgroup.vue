<template>
  <div>
    <div v-for="(dd,i) in adddata" :key="i">
      <childexchangegroup :msg="dd"/>
    </div>
  </div>
</template>
<script>
import childexchangegroup from "./childexchangegroup.vue";
export default {
  name: "exchangesgroup",
  components: {
    childexchangegroup
  },
  data: () => ({
    groups: []
  }),
  computed: {
    adddata() {
      return this.$store.state.exchangenames;
    }
  }
};
</script>
