<template>
  <div>
    <div>
      Ethereum tracker helps you track movements of ethereum,
      this will help you in tracking prices, when some one is bulk selling you know it
    </div>
    <div>when some whale tries to move ether, we know it, we know the price going to drop, now we know it, we can play games</div>
    <div>
      <v-card>
        image source
        <img
          src="https://lh3.googleusercontent.com/BHpK47ScCfG8zQECDz25HtPpVbIVAuCGmF1wjiIdP15a9kTZt6gs9RbdzGcfHK9HMXRbSQNaPA=w640-h400-e365"
        >
        Developers contributing to the ethereum protocol are electing to hold off on a decision to submit code that would stifle the advantage of high-powered ASIC miners competing for the network’s rewards.
        During a public call Friday, which included Hudson Jameson, Lane Rettig, Afri Schodedon, Martin Holst Swende, Danno Ferrin and Greg Colvin, among other notable developers, a tentative decision was reached to postpone the so-called ProgPow upgrade in favor of conducting continued audits.
        These third-party audits will look to verify that implementing the algorithm will reduce ASIC efficiency so as to make them less competitive against GPUs, a cheaper and more consumer-friendly mining technology.
        A number of the call’s participants expressed discomfort with providing a firm decision on whether to execute the algorithm, leading to the delay.
        The decision stems from a push to avoid a consolidation in the number of participants verifying transactions on ethereum. If implemented, the algorithm would theoretically allow for a greater number of miners to participate in the network.
        Jameson, a communications officer with the Ethereum Foundation, said a third-party audit will likely answer many questions the community still has about the update.
        “If we can get to a point where we say, ‘This will work and here’s why it will work,’ that would help a lot,” Jameson said of the audit, later adding:
      </v-card>
    </div>
    <div>
      <v-card>
        Developers contributing to the ethereum protocol are electing to hold off on a decision to submit code that would stifle the advantage of high-powered ASIC miners competing for the network’s rewards.
        During a public call Friday, which included Hudson Jameson, Lane Rettig, Afri Schodedon, Martin Holst Swende, Danno Ferrin and Greg Colvin, among other notable developers, a tentative decision was reached to postpone the so-called ProgPow upgrade in favor of conducting continued audits.
        These third-party audits will look to verify that implementing the algorithm will reduce ASIC efficiency so as to make them less competitive against GPUs, a cheaper and more consumer-friendly mining technology.
        A number of the call’s participants expressed discomfort with providing a firm decision on whether to execute the algorithm, leading to the delay.
        The decision stems from a push to avoid a consolidation in the number of participants verifying transactions on ethereum. If implemented, the algorithm would theoretically allow for a greater number of miners to participate in the network.
        Jameson, a communications officer with the Ethereum Foundation, said a third-party audit will likely answer many questions the community still has about the update.
        “If we can get to a point where we say, ‘This will work and here’s why it will work,’ that would help a lot,” Jameson said of the audit, later adding:
      </v-card>
    </div>
  </div>
</template>
<script>
export default {
  data: () => ({
    items: [{ title: "Chat", icon: require("@/assets/ether.png") }]
  })
};
</script>

