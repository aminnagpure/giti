
<template>
  <v-layout child-flex :class="splclass">
    <v-card raised v-if="items.length>0">
      <v-card-title>
        <span class="headline font-weight-bold">{{items[0].exchange}}</span>
      </v-card-title>

      <v-card-text class="title font-weight-light">
        difference in balance
        {{finaleth()}}
      </v-card-text>
      <v-card-text>
        {{msg}}
        {{finalsay()}}
      </v-card-text>

      <v-spacer></v-spacer>
    </v-card>
  </v-layout>
</template>

<script>
import { db } from "../components/data";
export default {
  name: "childexchangegroup",
  data: function() {
    return { items: [], splclass: "cssprops" };
  },
  created() {
    this.getdata();
  },
  props: ["msg"],
  methods: {
    getdata() {
      console.log("getadata", this.msg);
      db.collection("exchangesgroup")
        .where("exchange", "==", this.msg)
        .onSnapshot(abc => {
          abc.docChanges().forEach(ll => {
            this.items.push(ll.doc.data());
          });
        });
    },
    finaleth() {
      //console.log(this.items.map(kk => kk.totaleth));

      if (this.items.length > 0) {
        return (
          this.items[0].totaleth - this.items[this.items.length - 1].totaleth
        );
      }
    },
    maping() {
      this.items.map(kk => kk.totaleth);
    },
    getMinY() {
      let abc = this.items.map(kk => kk.totaleth);
      console.log("abc", abc);
      return Math.min(...abc);
    },
    getMaxY() {
      return Math.max(...this.maping());
    },
    finalsay() {
      //  console.log(this.finaleth());
      let kk = this.finaleth();
      if (kk > 100000) {
        this.splclass = "redclass";
        return "market looks like it gona collapse ";
      }
      if (kk > 90000) {
        this.splclass = "redclass";
        return "market will be  very heavy down red ";
      }
      if (kk > 80000) {
        this.splclass = "redclass";
        return "market will be very heavy red ";
      }
      if (kk > 70000) {
        this.splclass = "redclass";
        return "market will be heavy red ";
      }
      if (kk > 60000) {
        this.splclass = "redclass";
        return "market will be heavy red ";
      }
      if (kk > 50000) {
        this.splclass = "purpleclass";
        return "market will be  red ";
      }
      if (kk > 40000) {
        this.splclass = "redclass";
        return "market will be quite red ";
      }
      if (kk > 30000) {
        this.splclass = "redclass";
        return "market will be red ";
      }
      if (-500000 > kk) {
        this.splclass = "supergreenclass";
        return "market looks like it gona super pump very hard ";
      }
      if (-100000 > kk) {
        this.splclass = "greenclass";
        return "market looks like it gona pump very hard ";
      }
      if (-90000 > kk) {
        this.splclass = "greenclass";
        return "market looks like it gona pump quite hard ";
      }
    }
  }
};
</script>
<style lang="scss" scoped>
.redclass {
  .theme--light.v-sheet {
    background-color: red;
    body {
      color: green;
    }
  }
}

.greenclass {
  .theme--light.v-sheet {
    background-color: green;
  }
}
.purpleclass {
  .theme--light.v-sheet {
    background-color: orangered;
  }
}
.supergreenclass {
  .theme--light.v-sheet {
    background-color: greenyellow;
  }
}
</style>










