<template>
  <v-container fluid grid-list-md>
    <v-layout row wrap>
      <v-flex d-flex xs12 sm6 md4>
        <v-card color="purple" dark>
          <v-card-title primary class="title">Groups</v-card-title>
          <v-card-text>You can Create your own group and communicate with them</v-card-text>
        </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-layout row wrap>
          <v-flex d-flex>
            <v-card color="indigo" dark>
              <v-card-text>
                <completemarketwatch/>
              </v-card-text>
            </v-card>
          </v-flex>
        </v-layout>
      </v-flex>
      <v-flex d-flex xs12 sm6 md2 child-flex>
        <v-card white>
          <v-card-text>
            <exchangesgroup msg="msg"/>
          </v-card-text>
        </v-card>
      </v-flex>
      <v-flex d-flex xs12 sm6 md3>
        <v-card white>
          <v-card-text>
            <chatbox/>
          </v-card-text>
        </v-card>
      </v-flex>
    </v-layout>
  </v-container>
</template>
<script>
import chatbox from "../components/chatbox";
import exchangesgroup from "../components/exchangesgroup";
import completemarketwatch from "../components/completemarketwatch";
export default {
  data: () => ({
    lorem: `Lorem ipsum dolor sit amet, mel at clita quando. Te sit oratio vituperatoribus, nam ad ipsum posidonium mediocritatem, explicari dissentiunt cu mea. Repudiare disputationi vim in, mollis iriure nec cu, alienum argumentum ius ad. Pri eu justo aeque torquatos.`,
    exch: [],
    chat: [], // getChats(), //store.state.chatmsglist,
    msg: []
  }),
  created() {
    //this.getChats();
    //this.getchats();
  },
  methods: {
    getexchangenames() {
      /* this.$store.state.arryofexchangenames.forEach(element => {
        return element;
      });
      */
      console.log(this.$store.state.arryofexchangenames);
      console.log(this.msg, "msg");
    }
  },
  components: {
    chatbox,
    exchangesgroup,
    completemarketwatch
  }
};
</script>